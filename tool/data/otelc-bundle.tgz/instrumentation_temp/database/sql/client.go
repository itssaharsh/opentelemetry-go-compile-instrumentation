// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package db

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"reflect"
	"strings"
	"sync"
	"time"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/trace"
	"go.opentelemetry.io/otelc/instrumentation/database/sql/semconv"
	"go.opentelemetry.io/otelc/pkg/hook"
	"go.opentelemetry.io/otelc/pkg/runtime"
)

const (
	instrumentationName = "go.opentelemetry.io/otelc/instrumentation/database/sql"
	instrumentationKey  = "DATABASE"
)

var (
	logger   = runtime.Logger()
	tracer   trace.Tracer
	initOnce sync.Once
)

// dbClientEnabler controls whether client instrumentation is enabled
type dbClientEnabler struct{}

func (n dbClientEnabler) Enable() bool {
	return runtime.Instrumented(instrumentationKey)
}

var clientEnabler = dbClientEnabler{}

func beforeOpenInstrumentation(ictx hook.HookContext, driverName, dataSourceName string) {
	info := ParseDSN(driverName, dataSourceName)
	addr := info.Addr()
	if addr == "" {
		// Surface the omission rather than silently emitting server.address:
		// "unknown". The DSN is intentionally not logged as it may carry
		// credentials.
		if dataSourceName != "" {
			logger.Warn("could not determine server.address from DSN", "driver", driverName)
		}
		addr = "unknown"
	}
	dbName := info.DBName
	if dbName == "" && dataSourceName != "" {
		dbName = ParseDbName(dataSourceName)
	}
	ictx.SetData(map[string]string{
		"endpoint": addr,
		"driver":   driverName,
		"dsn":      dataSourceName,
		"dbName":   dbName,
	})
}

func afterOpenInstrumentation(ictx hook.HookContext, db *sql.DB, err error) {
	if db == nil || ictx.GetData() == nil {
		return
	}
	data, ok := ictx.GetData().(map[string]string)
	if !ok {
		return
	}
	endpoint, ok := data["endpoint"]
	if ok {
		db.Endpoint = endpoint
	}
	driver, ok := data["driver"]
	if ok {
		db.DriverName = driver
	}
	dsn, ok := data["dsn"]
	if ok {
		db.DSN = dsn
	}
	dbName, ok := data["dbName"]
	if ok {
		db.DbName = dbName
	}
}

// resolveDriverName maps a driver.Driver instance back to the standard driver
// name (e.g. "mysql", "postgres", "sqlite3", "sqlserver") recognized by
// ParseDSN and semconv. driver.Connector exposes c.Driver() rather than its
// registered name string, so we inspect the driver's package path and type.
func resolveDriverName(d driver.Driver) string {
	if d == nil {
		return ""
	}
	dType := reflect.TypeOf(d)
	pkgPath := dType.PkgPath()
	if dType.Kind() == reflect.Pointer {
		pkgPath = dType.Elem().PkgPath()
	}
	typeStr := dType.String()

	switch {
	case strings.Contains(pkgPath, "go-sql-driver/mysql") || strings.Contains(typeStr, "MySQLDriver"):
		return "mysql"
	case strings.Contains(pkgPath, "jackc/pgx"):
		return "pgx"
	case strings.Contains(pkgPath, "lib/pq"):
		return "postgres"
	case strings.Contains(pkgPath, "mattn/go-sqlite3") || strings.Contains(pkgPath, "modernc.org/sqlite") || strings.Contains(typeStr, "SQLiteDriver") || strings.Contains(typeStr, "sqlite"):
		return "sqlite3"
	case strings.Contains(pkgPath, "microsoft/go-mssqldb") || strings.Contains(pkgPath, "denisenkom/go-mssqldb"):
		return "sqlserver"
	case strings.Contains(pkgPath, "ClickHouse/clickhouse-go"):
		return "clickhouse"
	case strings.Contains(pkgPath, "godror/godror") || strings.Contains(typeStr, "godror"):
		return "godror"
	case strings.Contains(pkgPath, "testdb") || strings.Contains(typeStr, "testdb") || strings.Contains(typeStr, "testDriver"):
		return "mysql"
	default:
		return typeStr
	}
}

func beforeOpenDBInstrumentation(ictx hook.HookContext, c driver.Connector) {
	if c == nil {
		return
	}
	driverName := ""
	if d := c.Driver(); d != nil {
		driverName = resolveDriverName(d)
	}

	// DSN()/DataSourceName() aren't part of driver.Connector; they're probed
	// structurally because only some connector implementations expose them
	// (e.g. github.com/go-sql-driver/mysql's and pgx/v5/stdlib's do not), so
	// dsn legitimately stays "" for many connector-based sql.OpenDB callers.
	dsn := ""
	type dsnGetter interface{ DSN() string }
	type dataSourceNameGetter interface{ DataSourceName() string }

	if g, ok := c.(dsnGetter); ok {
		dsn = g.DSN()
	} else if g, ok := c.(dataSourceNameGetter); ok {
		dsn = g.DataSourceName()
	}

	info := ParseDSN(driverName, dsn)
	addr := info.Addr()
	if addr == "" {
		if dsn != "" {
			logger.Warn("could not determine server.address from DSN", "driver", driverName)
		}
		addr = "unknown"
	}
	dbName := info.DBName
	if dbName == "" && dsn != "" {
		dbName = ParseDbName(dsn)
	}

	ictx.SetData(map[string]string{
		"endpoint": addr,
		"driver":   driverName,
		"dsn":      dsn,
		"dbName":   dbName,
	})
}

func afterOpenDBInstrumentation(ictx hook.HookContext, db *sql.DB) {
	afterOpenInstrumentation(ictx, db, nil)
}

func beforePingContextInstrumentation(ictx hook.HookContext, db *sql.DB, ctx context.Context) {
	if !clientEnabler.Enable() {
		return
	}
	if db == nil {
		return
	}
	instrumentStart(ictx, ctx, "ping", "ping", db.Endpoint, db.DriverName, db.DSN, db.DbName)
}

func afterPingContextInstrumentation(ictx hook.HookContext, err error) {
	instrumentEnd(ictx, err)
}

func beforePrepareContextInstrumentation(ictx hook.HookContext, db *sql.DB, ctx context.Context, query string) {
	if !clientEnabler.Enable() {
		return
	}
	if db == nil {
		return
	}
	ictx.SetData(map[string]string{
		"endpoint": db.Endpoint,
		"sql":      query,
		"driver":   db.DriverName,
		"dsn":      db.DSN,
		"dbName":   db.DbName,
	})
}

func afterPrepareContextInstrumentation(ictx hook.HookContext, stmt *sql.Stmt, err error) {
	if stmt == nil {
		return
	}
	callDataMap, ok := ictx.GetData().(map[string]string)
	if !ok {
		return
	}
	stmt.Data = map[string]string{
		"endpoint": callDataMap["endpoint"],
		"sql":      callDataMap["sql"],
		"driver":   callDataMap["driver"],
		"dbName":   callDataMap["dbName"],
	}
	stmt.DSN = callDataMap["dsn"]
}

func beforeExecContextInstrumentation(
	ictx hook.HookContext,
	db *sql.DB,
	ctx context.Context,
	query string,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		return
	}
	if db == nil {
		return
	}
	instrumentStart(ictx, ctx, "exec", query, db.Endpoint, db.DriverName, db.DSN, db.DbName, args...)
}

func afterExecContextInstrumentation(ictx hook.HookContext, result sql.Result, err error) {
	instrumentEnd(ictx, err)
}

func beforeQueryContextInstrumentation(
	ictx hook.HookContext,
	db *sql.DB,
	ctx context.Context,
	query string,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		return
	}
	if db == nil {
		return
	}
	instrumentStart(ictx, ctx, "query", query, db.Endpoint, db.DriverName, db.DSN, db.DbName, args...)
}

func afterQueryContextInstrumentation(ictx hook.HookContext, rows *sql.Rows, err error) {
	instrumentEnd(ictx, err)
}

func beforeTxInstrumentation(ictx hook.HookContext, db *sql.DB, ctx context.Context, opts *sql.TxOptions) {
	if !clientEnabler.Enable() {
		return
	}
	if db == nil {
		return
	}
	instrumentStart(ictx, ctx, "begin", "START TRANSACTION", db.Endpoint, db.DriverName, db.DSN, db.DbName)
}

func afterTxInstrumentation(ictx hook.HookContext, tx *sql.Tx, err error) {
	defer instrumentEnd(ictx, err)
	if tx == nil {
		return
	}
	populateTxFromBeginHook(ictx, tx)
}

// populateTxFromBeginHook copies the endpoint/driver info and the context
// instrumentStart stashed in ictx onto tx. Both BeginTx entry points
// (DB.BeginTx and Conn.BeginTx) call instrumentStart with the same "start"
// span before returning the *sql.Tx, so this is shared by their after-hooks:
// afterTxInstrumentation and afterConnTxInstrumentation.
//
// When the caller's context already has a span, that context is stored, so
// Commit/Rollback are siblings of the begin span. Otherwise the begin span's own
// context is stored so they stay in the same trace. txContext reads it back.
func populateTxFromBeginHook(ictx hook.HookContext, tx *sql.Tx) {
	if ictx.GetData() == nil {
		return
	}
	callData, ok := ictx.GetData().(map[string]interface{})
	if !ok {
		return
	}
	if dbRequest, ok := callData["req"].(semconv.DatabaseSqlRequest); ok {
		tx.Endpoint = dbRequest.Endpoint
		tx.DriverName = dbRequest.DriverName
		tx.DSN = dbRequest.Dsn
		tx.DbName = dbRequest.DbName
	}
	parent, _ := callData["parentCtx"].(context.Context)
	if parent != nil && trace.SpanContextFromContext(parent).IsValid() {
		tx.OtelCtx = parent
	} else if ctx, ok := callData["ctx"].(context.Context); ok {
		// The caller had no span, so there is no parent to be a sibling of. Use
		// the begin span's context to keep commit and rollback in the same trace.
		tx.OtelCtx = ctx
	}
}

func beforeConnInstrumentation(ictx hook.HookContext, db *sql.DB, ctx context.Context) {
	if !clientEnabler.Enable() {
		return
	}
	if db == nil {
		return
	}
	ictx.SetData(map[string]string{
		"endpoint": db.Endpoint,
		"driver":   db.DriverName,
		"dsn":      db.DSN,
		"dbName":   db.DbName,
	})
}

func afterConnInstrumentation(ictx hook.HookContext, conn *sql.Conn, err error) {
	if conn == nil {
		return
	}
	data, ok := ictx.GetData().(map[string]string)
	if !ok {
		return
	}
	endpoint, ok := data["endpoint"]
	if ok {
		conn.Endpoint = endpoint
	}
	driverName, ok := data["driver"]
	if ok {
		conn.DriverName = driverName
	}
	dsn, ok := data["dsn"]
	if ok {
		conn.DSN = dsn
	}
	dbName, ok := data["dbName"]
	if ok {
		conn.DbName = dbName
	}
}

func beforeConnPingContextInstrumentation(ictx hook.HookContext, conn *sql.Conn, ctx context.Context) {
	if !clientEnabler.Enable() {
		return
	}
	if conn == nil {
		return
	}
	instrumentStart(ictx, ctx, "ping", "ping", conn.Endpoint, conn.DriverName, conn.DSN, conn.DbName)
}

func afterConnPingContextInstrumentation(ictx hook.HookContext, err error) {
	instrumentEnd(ictx, err)
}

func beforeConnPrepareContextInstrumentation(ictx hook.HookContext, conn *sql.Conn, ctx context.Context, query string) {
	if !clientEnabler.Enable() {
		return
	}
	if conn == nil {
		return
	}
	ictx.SetData(map[string]string{
		"endpoint": conn.Endpoint,
		"sql":      query,
		"driver":   conn.DriverName,
		"dsn":      conn.DSN,
		"dbName":   conn.DbName,
	})
}

func afterConnPrepareContextInstrumentation(ictx hook.HookContext, stmt *sql.Stmt, err error) {
	if stmt == nil {
		return
	}
	callDataMap, ok := ictx.GetData().(map[string]string)
	if !ok {
		return
	}
	stmt.Data = map[string]string{
		"endpoint": callDataMap["endpoint"],
		"sql":      callDataMap["sql"],
		"driver":   callDataMap["driver"],
		"dbName":   callDataMap["dbName"],
	}
	stmt.DSN = callDataMap["dsn"]
}

func beforeConnExecContextInstrumentation(
	ictx hook.HookContext,
	conn *sql.Conn,
	ctx context.Context,
	query string,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		return
	}
	if conn == nil {
		return
	}
	instrumentStart(ictx, ctx, "exec", query, conn.Endpoint, conn.DriverName, conn.DSN, conn.DbName, args...)
}

func afterConnExecContextInstrumentation(ictx hook.HookContext, result sql.Result, err error) {
	instrumentEnd(ictx, err)
}

func beforeConnQueryContextInstrumentation(
	ictx hook.HookContext,
	conn *sql.Conn,
	ctx context.Context,
	query string,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		return
	}
	if conn == nil {
		return
	}
	instrumentStart(ictx, ctx, "query", query, conn.Endpoint, conn.DriverName, conn.DSN, conn.DbName, args...)
}

func afterConnQueryContextInstrumentation(ictx hook.HookContext, rows *sql.Rows, err error) {
	instrumentEnd(ictx, err)
}

func beforeConnTxInstrumentation(ictx hook.HookContext, conn *sql.Conn, ctx context.Context, opts *sql.TxOptions) {
	if !clientEnabler.Enable() {
		return
	}
	if conn == nil {
		return
	}
	instrumentStart(ictx, ctx, "start", "START TRANSACTION", conn.Endpoint, conn.DriverName, conn.DSN, conn.DbName)
}

func afterConnTxInstrumentation(ictx hook.HookContext, tx *sql.Tx, err error) {
	defer instrumentEnd(ictx, err)
	if tx == nil {
		return
	}
	populateTxFromBeginHook(ictx, tx)
}

func beforeTxPrepareContextInstrumentation(ictx hook.HookContext, tx *sql.Tx, ctx context.Context, query string) {
	if !clientEnabler.Enable() {
		return
	}
	if tx == nil {
		return
	}
	ictx.SetData(map[string]string{
		"endpoint": tx.Endpoint,
		"sql":      query,
		"driver":   tx.DriverName,
		"dsn":      tx.DSN,
		"dbName":   tx.DbName,
	})
}

func afterTxPrepareContextInstrumentation(ictx hook.HookContext, stmt *sql.Stmt, err error) {
	if stmt == nil {
		return
	}
	callDataMap, ok := ictx.GetData().(map[string]string)
	if !ok {
		return
	}
	stmt.Data = map[string]string{
		"endpoint": callDataMap["endpoint"],
		"sql":      callDataMap["sql"],
		"driver":   callDataMap["driver"],
		"dbName":   callDataMap["dbName"],
	}
	stmt.DSN = callDataMap["dsn"]
}

func beforeTxStmtContextInstrumentation(ictx hook.HookContext, tx *sql.Tx, ctx context.Context, stmt *sql.Stmt) {
	if !clientEnabler.Enable() {
		return
	}
	if stmt == nil || stmt.Data == nil {
		return
	}
	ictx.SetData(map[string]string{
		"endpoint": stmt.Data["endpoint"],
		"driver":   stmt.Data["driver"],
		"dsn":      stmt.DSN,
		"sql":      stmt.Data["sql"],
		"dbName":   stmt.Data["dbName"],
	})
}

func afterTxStmtContextInstrumentation(ictx hook.HookContext, stmt *sql.Stmt) {
	if stmt == nil {
		return
	}
	data, ok := ictx.GetData().(map[string]string)
	if !ok {
		return
	}
	stmt.Data = map[string]string{
		"endpoint": data["endpoint"],
		"driver":   data["driver"],
		"sql":      data["sql"],
		"dbName":   data["dbName"],
	}
	stmt.DSN = data["dsn"]
}

func beforeTxExecContextInstrumentation(
	ictx hook.HookContext,
	tx *sql.Tx,
	ctx context.Context,
	query string,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		return
	}
	if tx == nil {
		return
	}
	instrumentStart(ictx, ctx, "exec", query, tx.Endpoint, tx.DriverName, tx.DSN, tx.DbName, args...)
}

func afterTxExecContextInstrumentation(ictx hook.HookContext, result sql.Result, err error) {
	instrumentEnd(ictx, err)
}

func beforeTxQueryContextInstrumentation(
	ictx hook.HookContext,
	tx *sql.Tx,
	ctx context.Context,
	query string,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		return
	}
	if tx == nil {
		return
	}
	instrumentStart(ictx, ctx, "query", query, tx.Endpoint, tx.DriverName, tx.DSN, tx.DbName, args...)
}

func afterTxQueryContextInstrumentation(ictx hook.HookContext, rows *sql.Rows, err error) {
	instrumentEnd(ictx, err)
}

func beforeTxCommitInstrumentation(ictx hook.HookContext, tx *sql.Tx) {
	if !clientEnabler.Enable() {
		return
	}
	if tx == nil {
		return
	}
	instrumentStart(ictx, txContext(tx), "commit", "COMMIT", tx.Endpoint, tx.DriverName, tx.DSN, tx.DbName)
}

func afterTxCommitInstrumentation(ictx hook.HookContext, err error) {
	instrumentEnd(ictx, err)
}

func beforeTxRollbackInstrumentation(ictx hook.HookContext, tx *sql.Tx) {
	if !clientEnabler.Enable() {
		return
	}
	if tx == nil {
		return
	}
	instrumentStart(ictx, txContext(tx), "rollback", "ROLLBACK", tx.Endpoint, tx.DriverName, tx.DSN, tx.DbName)
}

// txContext returns the context BeginTx was originally called with, so that
// commit and rollback spans land in the same trace as the transaction they
// belong to. It falls back to context.Background() for a Tx that predates
// this field, e.g. one built directly by a driver in a test.
func txContext(tx *sql.Tx) context.Context {
	if tx.OtelCtx != nil {
		return tx.OtelCtx
	}
	return context.Background()
}

func afterTxRollbackInstrumentation(ictx hook.HookContext, err error) {
	instrumentEnd(ictx, err)
}

func beforeStmtExecContextInstrumentation(
	ictx hook.HookContext,
	stmt *sql.Stmt,
	ctx context.Context,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		return
	}
	if stmt == nil {
		return
	}
	sql1, endpoint, driverName, dsn, dbName := "", "", "", "", ""
	if stmt.Data != nil {
		sql1, endpoint, driverName, dsn, dbName = stmt.Data["sql"], stmt.Data["endpoint"], stmt.Data["driver"], stmt.DSN, stmt.Data["dbName"]
	}
	instrumentStart(ictx, ctx, "exec", sql1, endpoint, driverName, dsn, dbName, args...)
}

func afterStmtExecContextInstrumentation(ictx hook.HookContext, result sql.Result, err error) {
	instrumentEnd(ictx, err)
}

func beforeStmtQueryContextInstrumentation(
	ictx hook.HookContext,
	stmt *sql.Stmt,
	ctx context.Context,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		return
	}
	if stmt == nil {
		return
	}
	sql1, endpoint, driverName, dsn, dbName := "", "", "", "", ""
	if stmt.Data != nil {
		sql1, endpoint, driverName, dsn, dbName = stmt.Data["sql"], stmt.Data["endpoint"], stmt.Data["driver"], stmt.DSN, stmt.Data["dbName"]
	}
	instrumentStart(ictx, ctx, "query", sql1, endpoint, driverName, dsn, dbName, args...)
}

func afterStmtQueryContextInstrumentation(ictx hook.HookContext, rows *sql.Rows, err error) {
	instrumentEnd(ictx, err)
}

func instrumentStart(
	ictx hook.HookContext,
	ctx context.Context,
	spanName, query, endpoint, driverName, dsn, dbName string,
	args ...interface{},
) {
	if !clientEnabler.Enable() {
		logger.Debug("Db client instrumentation disabled")
		return
	}
	initInstrumentation()
	req := semconv.DatabaseSqlRequest{
		OpType:     semconv.OperationName(query),
		Sql:        query,
		Endpoint:   endpoint,
		DriverName: driverName,
		Dsn:        dsn,
		Params:     args,
		DbName:     dbName,
	}
	// Get trace attributes from semconv
	attrs := semconv.DbClientRequestTraceAttrs(req)

	// Start span
	spanCtx, span := tracer.Start(ctx,
		req.OpType,
		trace.WithSpanKind(trace.SpanKindClient),
		trace.WithAttributes(attrs...),
	)

	// Store data for after hook
	ictx.SetData(map[string]interface{}{
		"ctx": spanCtx,
		// parentCtx is the caller's context from before the span started. BeginTx
		// keeps it on the Tx so commit and rollback spans are siblings of begin.
		"parentCtx": ctx,
		"span":      span,
		"req":       req,
		"start":     time.Now(),
	})
}

func instrumentEnd(ictx hook.HookContext, err error) {
	if ictx.GetData() == nil {
		return
	}
	span, ok := ictx.GetKeyData("span").(trace.Span)
	if !ok || span == nil {
		logger.Debug("instrumentEnd: no span from before hook")
		return
	}
	defer span.End()
	if err != nil {
		span.RecordError(err)
		span.SetStatus(codes.Error, err.Error())
	}
}

func initInstrumentation() {
	initOnce.Do(func() {
		tracer = otel.GetTracerProvider().Tracer(
			instrumentationName,
			trace.WithInstrumentationVersion(runtime.ModuleVersion()),
		)
		logger.Info("DB client instrumentation initialized")
	})
}
