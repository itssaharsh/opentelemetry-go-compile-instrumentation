// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package semconv

import (
	"net"
	"strconv"
	"strings"

	"go.opentelemetry.io/otel/attribute"
	semconv "go.opentelemetry.io/otel/semconv/v1.37.0"
)

type DatabaseSqlRequest struct {
	OpType     string
	Sql        string
	Endpoint   string
	DriverName string
	Dsn        string
	Params     []any
	DbName     string
}

// OperationName returns the uppercased first token of a SQL statement for use
// as db.operation.name. Empty or whitespace-only input returns "".
func OperationName(query string) string {
	trimmed := strings.TrimSpace(query)
	if trimmed == "" {
		return ""
	}
	fields := strings.Fields(trimmed)
	return strings.ToUpper(fields[0])
}

func DbClientRequestTraceAttrs(req DatabaseSqlRequest) []attribute.KeyValue {
	host, portStr, err := net.SplitHostPort(req.Endpoint)
	if err != nil {
		host = req.Endpoint
	}

	attrs := []attribute.KeyValue{
		semconv.DBOperationName(req.OpType),
		semconv.DBNamespace(req.DbName),
		semconv.ServerAddress(host),
		semconv.NetworkTransportTCP,
		semconv.DBQueryText(req.Sql),
	}

	if err == nil {
		if port, convErr := strconv.Atoi(portStr); convErr == nil && port > 0 {
			attrs = append(attrs, semconv.ServerPort(port))
		}
	}

	switch req.DriverName {
	case "mysql", "mariadb":
		attrs = append(attrs, semconv.DBSystemNameMySQL)
	case "postgres", "postgresql", "pgx", "lib/pq":
		attrs = append(attrs, semconv.DBSystemNamePostgreSQL)
	case "sqlite3", "sqlite":
		attrs = append(attrs, semconv.DBSystemNameSQLite)
	case "clickhouse":
		attrs = append(attrs, semconv.DBSystemNameClickHouse)
	case "godror", "oracle", "oci8", "go-oci8":
		attrs = append(attrs, semconv.DBSystemNameOracleDB)
	case "mssql", "sqlserver":
		attrs = append(attrs, semconv.DBSystemNameMicrosoftSQLServer)
	default:
		attrs = append(attrs, semconv.DBSystemNameOtherSQL)
	}

	return attrs
}
